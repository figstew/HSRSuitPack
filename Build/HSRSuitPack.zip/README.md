# HSR Suit Pack v0.1.0
### Adds Honkai Star Rail characters to Lethal Company.
Enjoy!

## Characters
As of v0.1.0, the following characters are available:

- Anaxa
- Mydei
- Phainon
- Khaslana

## Manual Installation Instructions
- Place contents in `bepinex/plugins` folder in the zip file in `bepinex/plugins` folder in game root directory.
- Ensure that ModelReplacementAPI and MoreSuits are also installed.

## Changelog
	- v0.1.0
		- Release

## Credits
- All models by miHoYo.
- ModelReplacementAPI mod by BunyaPineTree.
- MoreSuits mod by x753.